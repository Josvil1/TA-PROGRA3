
package pe.edu.pucp.softprog.getPedido.model;

public enum EstadoPedido {
    CONFIRMADO, EN_PROCESO, CANCELADO
}
