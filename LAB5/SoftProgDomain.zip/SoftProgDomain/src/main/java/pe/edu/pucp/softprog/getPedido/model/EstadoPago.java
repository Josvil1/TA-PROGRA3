package pe.edu.pucp.softprog.getPedido.model;

public enum EstadoPago {
    APROBADO, PENDIENTE, CANCELADO
}
