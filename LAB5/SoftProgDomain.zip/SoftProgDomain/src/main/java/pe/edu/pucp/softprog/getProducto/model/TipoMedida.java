package pe.edu.pucp.softprog.getProducto.model;

public enum TipoMedida {
    DECENA,DOCENA,CENTENA,MILLAR
}
